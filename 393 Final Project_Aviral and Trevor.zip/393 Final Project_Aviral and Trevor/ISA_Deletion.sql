-- Deletion Scripts
DROP TABLE INTERNSHIP_REPORT;
DROP TABLE Company;
DROP TABLE Roles;
DROP TABLE Location;
DROP TABLE Member;
commit;