--problem 1
-- Member name and role
select m.f_name, m.l_name, ro.role_name
from internship_report r
join roles ro on ro.role_id = r.role_id
join member m on m.member_id = r.member_id;

--problem 2
-- Role comparison with ISA member avg and national avg
select ro.role_name, avg(r.salary) as avg_salary_isa, ro.avg_salary
from internship_report r
join roles ro on ro.role_id = r.role_id
group by ro.role_name, ro.avg_salary
order by avg_salary_isa desc;

--problem 3
select f_name, l_name
from internship_report i
join member m on m.member_id = i.member_id
where i.member_id in
(   
    
        --member list who beat role 1 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=1
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=1
        )
    
)
or i.member_id in
(
    
        --member list who beat role 2 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=2
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=2
        )
    
)
or i.member_id in
(
    
        --member list who beat role 3 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=3
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=3
        )
    
)
or i.member_id in
(
    
        --member list who beat role 4 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=4
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=4
        )
    
)
or i.member_id in
(
    
        --member list who beat role 5 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=5
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=5
        )
    
)
or i.member_id in
(
    
        --member list who beat role 6 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=6
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=6
        )
    
)
or i.member_id in
(
    
        --member list who beat role 7 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=7
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=7
        )
    
)
or i.member_id in
(
    
        --member list who beat role 8 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=8
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=8
        )
    
)
or i.member_id in
(
    
        --member list who beat role 9 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=9
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=9
        )
    
)
or i.member_id in
(
    
        --member list who beat role 10 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=10
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=10
        )
    
)
or i.member_id in
(
    
        --member list who beat role 11 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=11
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=11
        )
    
)
or i.member_id in
(
    
        --member list who beat role 12 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=12
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=12
        )
    
)
or i.member_id in
(
    
        --member list who beat role 13 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=13
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=13
        )
    
)
or i.member_id in
(
    
        --member list who beat role 14 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=14
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=14
        )
    
)
or i.member_id in
(
    
        --member list who beat role 15 national average
        select i.member_id
        from internship_report i
        --join members m on m.member_id = i.member_id
        where role_id=15
        and salary >
        (
            select avg(avg_salary) 
            from roles
            where role_id=15
        )
    
);
--ANSWER: Trevor Brown, Clay Kim, Karenna Hunt, Gautham Arunkumar, Josh Mendola, Ana Evans, Jessie Britingham, Gen Zolinksi, Analise Jones

--problem 4
--ISA members w/in top 10% of salaries
select f_name, l_name, salary
from internship_report i
join member m on m.member_id = i.member_id
where salary >=
(
    select percentile_cont(0.10) within group (order by salary desc)
    from internship_report
);
--ANSWER: Karenna Hunt, Gautham Arunkumar, Ana Evans, Gen Zolinksi, Analise Jones


--problem 5
-- Most popular companies to intern for
select company_name, count(i.company_id) as qty
from internship_report i
join company c on c.company_id=i.company_id
group by company_name
order by qty desc;
--ANSWER: EY, Oracle, KPMG, Lockheed Martin

-- problem 6
-- Most popular role among ISA members
select role_name, count(i.role_id) as qty
from internship_report i
join roles r on r.role_id=i.role_id
group by role_name
order by qty desc;
--ANSWER: Consultant

--problem 7
-- Best paying geographical location
select city, state, avg(salary) as avg_salary
from internship_report i
join location l on l.location_id = i.location_id
group by city, state
order by avg_salary desc;
--ANSWER: Sedona, AZ

--problem 8
--most popular geographic location to work at
select city, state, count(i.location_id) as qty
from internship_report i
join location l on l.location_id = i.location_id
group by city, state
order by qty desc;
--ANSWER: San Jose

--problem 9
--Are ISA members more likely to work for a current sponsor?
select count(i.company_id) as qty, is_sponsor
from internship_report i
join company c on c.company_id=i.company_id
group by is_sponsor;
--ANSWER: Yes

--problem 10
--Do sponsors pay interns more, on average?
select avg(i.salary) as avg_salary, is_sponsor
from internship_report i
join company c on c.company_id=i.company_id
group by is_sponsor;
--Answer: No